package com.nitu.GoogleApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoogleApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoogleApiApplication.class, args);
	}

}
